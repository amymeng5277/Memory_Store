service KeyValueService {
  /* add procedures here */
}
